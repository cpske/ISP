Continuous Integration Demo
============================

This project demonstrates use of Github Actions to build and test a Python project.  

1. Create a repository on Github containing this starter code
2. Add a Github Action to run unit tests.
3. Add a Github "Badge" showing test status to this README.

Next add a coverage report: 

1. modify your Github Action to run tests with code coverage
2. send a coverage report (as xml) to <https://codecov.io>
3. add a Codecov badge to this README

## Instructions

<https://cpske.github.io/ISP/automation/ci-demo-project>


