Continuous Integration Demo
============================
[![Build Status](https://travis-ci.com/jbrucker/demo-pyci.svg?branch=master)](https://travis-ci.com/jbrucker/demo-pyci)

This project demonstrates use of Github Actions to build and test a Python project.  
Create a repository on Github, then use Github Actions to build and test it.

Next: you will add an online code coverage report for your tests using <https://codecov.io>

## Instructions

These are somewhat out of date, since they apply to Travis-CI:
<https://cpske.github.io/ISP/automation/travis-demo-project>


