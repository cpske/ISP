# KU Cafe Menu

## Breakfast Menu

| Item                                   | Price |
|:---------------------------------------|------:|
| nothing yet                            |  0.0  |

## Lunch Menu

Coming soon.

etc.

---

We accept PromptPay, KUPay, Alipay, and cash. Sorry, no credit cards.
