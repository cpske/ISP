# KU Cafe

**TODO**: add hyperlinks and format these one per line. Remove this TODO.

Breakfast Menu
Lunch Menu
Dinner Menu
Night Food Menu
Beverages

## About Us

**TODO**: Each person adds himself to this list; **not** one person adds everyone

| Name      | Role      | Github   |
|:----------|-----------|----------|
| Your name | Your menu | @your_github_id |
| ...       | ...       | ...      |
